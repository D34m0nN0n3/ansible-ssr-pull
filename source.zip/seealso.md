## Ссылки на документацию

- [Ansible pull](https://docs.ansible.com/ansible/latest/cli/ansible-pull.html)
- [Ansible vault](https://docs.ansible.com/ansible/latest/user_guide/vault.html#passing-vault-ids)

## Дополнительные ссылки

- [Systemd timer](https://www.freedesktop.org/software/systemd/man/systemd.timer.html)
